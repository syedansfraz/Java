/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment.pkg3.p1;
import java.util.Random;
/**
 *
 * @author ans shah55
 */
public class Assignment3P1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int d1;
        int d2;
        int [] arr= new int [11];
        Random rand = new Random ();
        for (int i=0;i<36000;i++)
        {
            d1=1+rand.nextInt(6);
            d2=1+rand.nextInt(6);
            int sum = d1+d2;
            arr[sum-2]++;
        }
        System.out.println("Number "+"\tFrequency ");
        for(int i=0;i<arr.length;i++)
        {
            System.out.printf("%02d :   \t%d\n",i+2,arr[i]);
        }
        
    }
    
}
