/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package author;

/**
 *
 * @author ans shah55
 */
public class Book {
    
    private String AName;
    private String book;
    private String publisher;
    public Book(String Aname,String book,String publisher)
    {
        this.setAName(Aname);
        this.setBook(book);
        this.setpub(publisher);
    }
    public String getAName() {
        return AName;
    }

    public void setAName(String AName) {
        this.AName = AName;
    }

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getpub() {
        return publisher;
    }

    public void setpub(String city) {
        this.publisher = city;
    }
    
    public void getDisplay()
    {
        System.out.println(""+this.getAName()+"\n"+this.getBook()+"\n"+this.getpub());
    }
}
