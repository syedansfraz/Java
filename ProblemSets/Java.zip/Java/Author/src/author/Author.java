package author;
public class Author {
    public static void main(String[] args) {
        authorTest a1 = new authorTest("Ans","Shah","Islamabad");
        a1.checkCapital();
        a1.display();
        Address a2= new Address(10,"Second","Islamabad");
        a2.display();
        Book a3 = new Book ("Ans Fraz Subhani","Imran Khan (One Man Army)","Ebooks");
        a3.getDisplay();
    }
    
}
