/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package author;

/**
 *
 * @author ans shah55
 */
public class Address {
    private int hnumber;
    private String Street;
    private String city;
    public Address(int hnumber,String Street,String city)
    {
        this.setHnumber(hnumber);
        this.setStreet(Street);
        this.setCity(city);
    }

    public int getHnumber() {
        return hnumber;
    }

    public void setHnumber(int hnumber) {
        this.hnumber = hnumber;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String Street) {
        this.Street = Street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    public void display()
    {
        System.out.println(""+this.hnumber+" "+this.Street+" "+this.city);
    }
    
}
