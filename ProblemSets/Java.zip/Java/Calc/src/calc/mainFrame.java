/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calc;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;

/**
 *
 * @author ans shah55
 */
public class mainFrame extends JFrame
{
 public JTextField  mainTxt=new JTextField();
 public JButton btn9=new JButton("9");
 public JButton btn8=new JButton("8");
 public JButton btn7=new JButton("7");
 public JButton btn6=new JButton("6");
 public JButton btn5=new JButton("5");
 public JButton btn4=new JButton("4");
 public JButton btn3=new JButton("3");
 public JButton btn2=new JButton("2");
 public JButton btn1=new JButton("1");
 public JButton btn0=new JButton("0");
 
 public JButton plus=new JButton("+");
 public JButton eq=new JButton("=");
 
    public void intialize()
    {
        mainTxt.setText("0");
        mainTxt.setBounds(10,10,450,30);
        mainTxt.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        mainTxt.setHorizontalAlignment(SwingConstants.RIGHT);
        this.add(mainTxt);
        
        
        btn9.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn9.setBounds(10,60,60,40);
        btn9.addActionListener(new Btn_Even_Handling());
        this.add(btn9);
        
        btn8.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn8.setBounds(90,60,60,40);
        btn8.addActionListener(new Btn_Even_Handling());
        this.add(btn8);
        
         btn7.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn7.setBounds(170,60,60,40);
        btn7.addActionListener(new Btn_Even_Handling());
        this.add(btn7);
        
        btn6.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn6.setBounds(10,120,60,40);
        btn6.addActionListener(new Btn_Even_Handling());
        this.add(btn6);
        
        btn5.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn5.setBounds(90,120,60,40);
        btn5.addActionListener(new Btn_Even_Handling());
        this.add(btn5);
        
         btn4.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn4.setBounds(170,120,60,40);
        btn4.addActionListener(new Btn_Even_Handling());
        this.add(btn4);
        
            btn3.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn3.setBounds(10,180,60,40);
        btn3.addActionListener(new Btn_Even_Handling());
        this.add(btn3);
        
        btn2.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn2.setBounds(90,180,60,40);
        btn2.addActionListener(new Btn_Even_Handling());
        this.add(btn2);
        
         btn1.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn1.setBounds(170,180,60,40);
        btn1.addActionListener(new Btn_Even_Handling());
        this.add(btn1);
        
        btn0.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        btn0.setBounds(90,240,60,40);
        btn0.addActionListener(new Btn_Even_Handling());
        this.add(btn0);
        
         plus.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        plus.setBounds(90,300,60,40);
        plus.addActionListener(new Btn_Even_Handling());
        this.add(plus);
        
          eq.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
        eq.setBounds(170,300,60,40);
        eq.addActionListener(new Btn_Even_Handling());
        this.add(eq);
        
        
        
        
        
       
    }
    public class Btn_Even_Handling implements ActionListener
    {
        public static int val;
        @Override
        public void actionPerformed(ActionEvent e) 
        {   
            String txt=e.getActionCommand().trim();
            if(txt.compareTo("+")==0)
            {
                val=Integer.parseInt(mainTxt.getText());
                mainTxt.setText("0");
            }
            else
            if(txt.compareTo("=")==0)
            {
                System.out.print("Equal");
                int v=Integer.parseInt(mainTxt.getText());
                int res=(v+this.val);
                System.out.println(res);
                mainTxt.setText(Integer.toString(res));
            }
            else
                
            if(mainTxt.getText().compareTo("0")==0)
            {
               
                mainTxt.setText(txt);
            }
            else
            {
                mainTxt.setText(mainTxt.getText()+txt);
            }
        }
        
    }
}
