package doubly_ll;

public class Doubly_LL {

    Node head;

    class Node {

        int data;
        Node pre;
        Node next;

        Node(int data1) {
            this.data = data1;
            pre=null;
            next=null;

        }
    }

    public void addLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = null;
            head.pre = null;
        } else {
            Node currNode = head;
            while (currNode.next != null) {
                currNode = currNode.next;
            }
            currNode.next = newNode;
            newNode.pre = currNode;

        }
    }

    public void addFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.pre = null;
            head.next = null;
        } else {
            head.pre = newNode;
            newNode.next = head;
            head = newNode;
            head.pre=null;
        }
    }
    
    public void deleteFirst()
    {
        if(head==null)
        {
            System.out.println("List is Empty!");
        }
        else
        {
            head=head.next;
            head.pre=null;
            
        }
    }
    public void deleteLast()

    {
        if(head==null)
        {
            System.out.println("List is Empty!");
        }
        else
        {
            if(head.next==null)
            {
                head=null;
            }
            else{
            Node currNode=head;
//            Node currNext=head.next;
            while(currNode.next!=null)
            {
                currNode=currNode.next;
//                currNext=currNext.next;
            }
            currNode.pre.next=null;
            
        }}
    }
    public void deleteSpecific(int val)
    {
        if(head==null)
        {
            System.out.println("List is Empty!");
            return;
        }
        else
        {
            Node temp=head;
            while(temp!=null)
            {
                if(temp.data==val)
                {
                    if(temp.pre==null)
                    {
                        this.deleteFirst();
                    }
                    else if(temp.next==null)
                    {
                        this.deleteLast();
                    }
                    else{
                    temp.pre.next=temp.next;
                    temp.next.pre=temp.pre;
                    System.out.println("Node Deleted");
                    return;
                    }
                }
                temp=temp.next;
            }
        }
    }
    public void displayNode() {
        Node currentNode = head;
        if (head == null) {
            System.out.println("Doubly Linked List is empty");
            return;
        }
        System.out.println("Nodes in Doubly Linked List: ");
        while (currentNode != null) {
            System.out.print(currentNode.data + " ");
            currentNode = currentNode.next;
        }

    }

    public static void main(String[] args) {
        // TODO code application logic here
        Doubly_LL list = new Doubly_LL();
        list.addLast(1);
        list.addLast(2);
        list.addLast(3);
        list.addLast(4);
        list.addFirst(7);
        list.addFirst(8);
        list.addFirst(9);
        list.deleteFirst();
        list.deleteLast();
        list.deleteSpecific(2);
        
        list.displayNode();
    }

}
