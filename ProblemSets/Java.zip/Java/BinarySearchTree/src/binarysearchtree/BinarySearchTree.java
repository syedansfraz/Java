package binarysearchtree;
public class BinarySearchTree {
    
    
    static class Node{
        int data;
        Node left;
        Node right;
        
        Node(int data)
        {
            this.data=data;
        }
    }
    
    static public Node insert(Node root,int key){
        if(root ==null){
            root=new Node(key);
            return root;
        }
        else if (root.data>key)
        {
            root.left=insert(root.left,key);
        }
        else{
            root.right=insert(root.right,key);
        }
        return root;
    }
    
    public static void inorder(Node root)
    {
        if(root==null)
        {
            return;
        }
        inorder(root.left);
        System.out.println(root.data+"");
        inorder(root.right);
    }
    
    public static boolean search(Node root,int key)
    {
        if(root==null)
        {
            return false;
        }
        else if(root.data>key)
        {
            return search(root.left,key);
            
        }
        else if(root.data<key)
            return search(root.right,key);
        else
            return true;
    }
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Node root=null;
        int []val={10,8,9,7,11,12,13};
        for(int i =0;i<val.length;i++)
        {
            root=insert(root,val[i]);
        }
        
//        BinarySearchTree tree=new BinarySearchTree();
        inorder(root);
        
        if(search(root,9))
        {
            System.out.println("Found");
        }
        else
            System.out.println("Not Found");
    }
    
}
