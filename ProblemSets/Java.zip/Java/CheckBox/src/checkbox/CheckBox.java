package checkbox;
import java.awt.Color;
import javax.swing.JFrame;

public class CheckBox {
    public static void main(String[] args) {
         chkBoxFrame f=new chkBoxFrame();
        f.setSize(400,600);
        f.intialize();
        f.getContentPane().setBackground(Color.WHITE);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);

    }
    
}
