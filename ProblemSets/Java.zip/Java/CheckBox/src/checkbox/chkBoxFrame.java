
package checkbox;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.border.Border;
public class chkBoxFrame extends JFrame implements ItemListener{
    public JCheckBox chkBold=new JCheckBox();
    public JCheckBox chkItalic=new JCheckBox();
    public JTextArea txtMain=new JTextArea();
    public Font f=new Font("Times New Roman",Font.PLAIN,20);
    Border b = BorderFactory.createLineBorder(Color.BLACK, 2);
    public void intialize()
    {
         txtMain.setText("What's in your mind!!!");
        txtMain.setBounds(10,10,365,100);
        txtMain.setBorder(b);
        txtMain.setFont(f);
        this.add(txtMain);
        
        chkBold.setText("Bold");
        chkBold.setFont(f);
        chkBold.setBounds(50,120,80,40);
        chkBold.setBackground(Color.WHITE);
        chkBold.addItemListener(this);
        chkBold.setFocusable(false);
        this.add(chkBold);
        
        chkItalic.setText("Italic");
        chkItalic.setFont(f);
        chkItalic.setBounds(150,120,80,40);
        chkItalic.setBackground(Color.WHITE);
        chkItalic.setFocusable(false);
        this.add(chkItalic);

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if(chkBold.isSelected()&&chkItalic.isSelected())
        {
            Font f1 = new Font("Times New Roman",Font.BOLD+Font.ITALIC,20);
            txtMain.setFont(f1);
        }
        else
             if(chkBold.isSelected())
             {
                 Font f1=new Font("Times New Roman",Font.BOLD,20);
             txtMain.setFont(f1);
             }
         else
                 if(chkItalic.isSelected())
                 {
                     Font f1=new Font("Times New Roman",Font.ITALIC,20);
             txtMain.setFont(f1);
                 }
         else
                 {
                     txtMain.setFont(f);
                 }

    }

    
}
