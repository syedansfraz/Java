/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkgfinal;

/**
 *
 * @author ans shah55
 */
public class finallyy {
    public void initilizer(int... ans){
            for(int ans1:ans)
            {
                        System.out.println(ans1);

            }
    }
    
    
       
}
