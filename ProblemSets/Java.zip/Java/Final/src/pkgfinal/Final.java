/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgfinal;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ans shah55
 */
public class Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        finallyy ans=new finallyy();
        Scanner input=new Scanner(System.in);
        ArrayList<Integer> ans1=new ArrayList<Integer>();
        System.out.println("Enter Number to print:");
        int a=input.nextInt();
        
        ans1.add(a);
        ans.initilizer(a,112);
        ans.initilizer(1,2,3,4,5);
    }    
}
