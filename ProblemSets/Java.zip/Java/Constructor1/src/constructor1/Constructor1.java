package constructor1;
import java.util.Scanner;
public class Constructor1 {
    public static void main(String[] args) {
    {
        int cont=1;
        Account a= new Account();
        a.setBal(5000.0);
        Scanner input = new Scanner(System.in);
        System.out.println("Account No:");
        int accno=input.nextInt();
        a.setAccno(accno);
        System.out.println("Password: ");
        int accpass= input.nextInt();
        if (accpass == 1234)
        {
            System.out.println("Processing...\n");
            
                do{
            System.out.println("1- Current Amount\n2- Deposit\n3- Withdraw\n4- Receeipt Only");
            int fun= input.nextInt();
            switch(fun)
            {
                case 1:
                    System.out.println(""+a.checkBal());
                break;
                case 2:
                    System.out.println("How Much?");
                    double addition=input.nextDouble();
                    a.Dep(addition);
                    System.out.println("Your Transaction is done!");
                    break;
                case 3:
                    System.out.println("How Much");
                    double sub=input.nextDouble();
                    a.With(sub);
                    System.out.println("Thank You For Your Transaction");
                    break;
                case 4:
                    Account b= new Account("Ans Fraz", a.getBal(),a.getAccno());
                    break;
                default:
                    System.out.println("Wrong Choice");
            }
            System.out.println("Press 1 to continue...");
        cont=input.nextInt();
                }while(cont ==1);
                        }
    }
    }
}