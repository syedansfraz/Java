package constructor1;
public class Account {
    private int AccNo;
    private double AccBal;
    private double AccDeposit;
    private double AccWith;
    private String Dep;
    public void setAccno(int str)
    {
        this.AccNo=str;
    }
    public int getAccno()
    {
        return this.AccNo;
    } 
    public void setBal(double str)
    {
        this.AccBal=str;
    }
    public double getBal()
    {
     return this.AccBal;   
    }
    public void setDep(double str)
    {
        this.AccDeposit=str;
    }
    public double getDep()
    {
     return this.AccDeposit;   
    }
    public void setWith(double str)
    {
        this.AccWith=str;
    }
    public double getWith()
    {
        return this.AccWith;
    }
    public void printinfo()
    {
        System.out.println("Balance:"+this.AccBal);
        System.out.println("Account No:"+this.AccNo);
        System.out.println("Last Deposit:"+this.AccDeposit);
        System.out.println("Last Withdraw:"+this.AccWith);
    }
    public double checkBal()
    {
        return AccBal;
    }
    public void Dep(double str)
    {
        if(str>=0)
        {
            setDep(str);
            AccBal= AccBal+str;
        }
        else{
            System.out.println("Invalid Amount entered!");
        }
    }
    public void With(double str)
    {
        if (str <= this.AccBal && str >=0)
        {
            setWith(str);
            this.AccBal = this.AccBal-str;
        }
        else
        {
            System.out.println("OUT OF MONEY!");
        }
    }
    public Account ()
    {
        
    }
    public Account(String str, double str1,int str2)
    {
        System.out.println("Name:"+str);
        System.out.println("Acc No:"+str2);
        System.out.println("Balance:"+str1);
    }
}