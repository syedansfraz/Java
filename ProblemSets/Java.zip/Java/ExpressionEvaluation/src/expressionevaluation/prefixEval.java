/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expressionevaluation;

/**
 *
 * @author ans shah55
 */
public class prefixEval {
    String exp;
    Stack st=new Stack();
    public prefixEval(String exp1)
    {
        exp=exp1;
    }
    public double pref(){
//    for(int i=exp.length()-1;i>=0;i--)  for postfix evaluation
        for(int i=0;i<=exp.length()-1;i++)
        //changing for post because for pre we do reverse looping
    {
        char c = exp.charAt(i);
        if(Character.isDigit(c))
        {
            double d =Double.parseDouble(""+c);
            st.push(d);
        }
        else 
        {
          
            double op2=st.pop();
//            System.out.println("this is op1 "+op1);
            double op1=st.pop();
//            System.out.println("this is op2 "+op2);
            double bbc= calculate(op1,op2,c);
            st.push(bbc);
//            System.out.println(bbc);
        }
        
    }
    return st.pop();
    }
    public double calculate(double op1,double op2,char op)
    {
        if(op=='+')
        {
//            st.push(op1+op2);
            return op1+op2;
        }
        else if(op=='-')
        {
            return op1-op2;
        }
        else if(op=='*')
        {
            return op1*op2;
        }
        else if(op=='/')
        {
            return op1/op2;
        }
        else if(op=='%')
        {
            return op1%op2;
        }
        else if(op=='^')
        {
            return Math.pow(op1, op2);
        }
        else
        return 1111.0;
    }
    
}
