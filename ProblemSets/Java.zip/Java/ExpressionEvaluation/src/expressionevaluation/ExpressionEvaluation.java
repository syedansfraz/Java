/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package expressionevaluation;

/**
 *
 * @author ans shah55
 */
public class ExpressionEvaluation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        prefixEval ans=new prefixEval("+9/*232");
//        System.out.println("Answer:"+ans.pref());
            prefixEval ans=new prefixEval("923*2/+");
            System.out.println("Answer:"+ans.pref());
        //for postfix read from left to right and first pop will assign to op2 and second assign will assign to op1
//        Stack abc=new Stack ();
//        abc.display();
    }
    
}
