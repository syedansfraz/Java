/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package circularqueue;

/**
 *
 * @author ans shah55
 */
public class circling {
    int head=0;
    int tail=0;
    int size =5;
    int [] arr=new int[size];
    public boolean isFull(){
//        if()
    }
}
