/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3p5;

/**
 *
 * @author ans shah55
 */
public class Cards {
    private String face;
    private String suit;
    public Cards(String f, String s)
    {
       this.setFace(f);
       this.setSuit(s);
    }
    public String toString()
    {
        return String.format("%s of %s", this.getFace(),this.getSuit());
    }
    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getSuit() {
        return suit;
    }

    public void setSuit(String suit) {
        this.suit = suit;

}
}
