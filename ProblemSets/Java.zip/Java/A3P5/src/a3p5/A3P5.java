package a3p5;
public class A3P5 {
    public static void main(String[] args) {
        Shuffle a= new Shuffle();
        a.pair();
        
    }
    
}
