/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3p5;
import java.util.Random;
/**
 *
 * @author ans shah55
 */

public class Shuffle {
    Random  rand=new Random();
    static final int size=52;
    private Cards [] deck=new Cards[size];

    public void pair()
    {
        int count=0;
        int []a= new int [size];
        System.out.println("Lets Assume the cards in hand are first five:\n");
        for(int i=0;i<size;i++)
        {
            int index =rand.nextInt(size);
            int temp=a[i];
            a[i]=a[index];
//            System.out.println(" "+i+" "+a[i]);
        }
        for(int i =0;i<5;i++)
        {
            for(int j =i+1;j<5;j++)
            {
                if(a[i]==a[j])
                {
                    count ++;
                    System.out.printf("\nA Hand contain Pair of ",a[i],a[j]);
                }      
            }
                }
        if(count ==0)
        {
            System.out.println("No pair found!");
        }
    }
    public Shuffle()
    {
        String [] fc={"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
    String [] st={"Hearts","Diamond","Spade","Club"};
    for(int i=0; i<this.size; i++)
    {
        this.deck[i]=new Cards(fc[i%13],st[i/13]);
    }

    }
}

