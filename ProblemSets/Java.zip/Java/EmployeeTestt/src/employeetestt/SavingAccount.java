/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeetestt;

/**
 *
 * @author ans shah55
 */
public class SavingAccount {
     private double accBalance;
    private static double aIRate;
    public SavingAccount(double d)
    {
        this.accBalance=d;
    }
    public static void modifyIntersetRate(double ir)
    {
      aIRate=ir;  
    }
    public void calculateMonthlyInterest()
    {
        double mi=(this.accBalance *aIRate)/12;
        this.accBalance= this.accBalance-mi;
    }
    public double getAccBalance() {
        return accBalance;
    }
    public void setAccBalance(double accBalance) {
        this.accBalance = accBalance;}
}