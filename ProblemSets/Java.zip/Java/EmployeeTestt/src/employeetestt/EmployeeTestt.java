package employeetestt;
public class EmployeeTestt {
    public static void main(String[] args) {
        Employee.setCount(0);
        Employee e1=new Employee("Syed","Ans");
        SavingAccount s1= new SavingAccount(5000.0);
        SavingAccount.modifyIntersetRate(0.1);
        s1.calculateMonthlyInterest();
        System.out.println("Id: "+e1.getEmpid()+"\nFirst Name:"+e1.getfName()+"\nLast Name:"+e1.getlName()+"\nAccount Balance:"+s1.getAccBalance());
        Employee e2=new Employee("Ali","Hassan");
        SavingAccount s2= new SavingAccount(1300.0);
        SavingAccount.modifyIntersetRate(0.1);
        s2.calculateMonthlyInterest();
        System.out.println("Id: "+e2.getEmpid()+"\nFirst Name:"+e2.getfName()+"\nLast Name:"+e2.getlName()+"\nAccount Balance:"+s2.getAccBalance());
        Employee e3=new Employee("Mukarram","Arshad");
        SavingAccount s3= new SavingAccount(7500.0);
        SavingAccount.modifyIntersetRate(0.1);
        s3.calculateMonthlyInterest();
        System.out.println("Id: "+e3.getEmpid()+"\nFirst Name:"+e3.getfName()+"\nLast Name:"+e3.getlName()+"\nAccount Balance:"+s3.getAccBalance());
        Employee e4=new Employee("Haider","Ali");
        SavingAccount s4= new SavingAccount(4250.0);
        SavingAccount.modifyIntersetRate(0.1);
        s4.calculateMonthlyInterest();
        System.out.println("Id: "+e4.getEmpid()+"\nFirst Name:"+e4.getfName()+"\nLast Name:"+e4.getlName()+"\nAccount Balance:"+s4.getAccBalance());
        Employee e5=new Employee("Mustafa","Ali");
        SavingAccount s5= new SavingAccount(3400.0);
        SavingAccount.modifyIntersetRate(0.1);
        s5.calculateMonthlyInterest();
        System.out.println("Id: "+e5.getEmpid()+"\nFirst Name:"+e5.getfName()+"\nLast Name:"+e5.getlName()+"\nAccount Balance:"+s5.getAccBalance());
        Employee e6=new Employee("muzzamil","Hassan");
        SavingAccount s6= new SavingAccount(4250.0);
        SavingAccount.modifyIntersetRate(0.1);
        s4.calculateMonthlyInterest();
        System.out.println("Id: "+e6.getEmpid()+"\nFirst Name:"+e6.getfName()+"\nLast Name:"+e6.getlName()+"\nAccount Balance:"+s6.getAccBalance());
    }
    
}
