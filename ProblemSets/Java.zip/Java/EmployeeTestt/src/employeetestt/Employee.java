/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeetestt;

/**
 *
 * @author ans shah55
 */
public class Employee {
private String fName;
private String lName;
private int empid;
public  static int count;
public Employee(String fn, String ln)
{
    this.setEmpid(++count);
    this.setfName(fn);
    this.setlName(ln);

}

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

public static int getCount()
{
    return count;
    
}
public static void setCount(int x)
{
        count=x;
}
public String toString()
{
    return String.format("First Name: %s Last Name: %s\n", this.getfName(),this.getlName());
}
    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;}
}
