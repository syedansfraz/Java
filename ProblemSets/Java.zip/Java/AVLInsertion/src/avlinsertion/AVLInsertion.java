/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package avlinsertion;
import java.io.*;
import java.util.*;
/**
 *
 * @author ans shah55
 */
public class AVLInsertion {
    
    class Node{
        Node left;
        Node right;
        int data;
        private int height;
        Node(int data1)
        {
            this.data=data1;
        }
    }
    
    public int height(Node root)
    {
        if(root!=null)
            return root.height;
        return 0;
    }
    class int getbalance(Node root)
    {
        if(root!=null)
            return height(root.left)- height(root.right);
        return 0;
    }
    
    class Node rotateRight(Node x)
            {
        Node y=x.left;
        Node t=y.right;
        
        y.right=x;
        x.left=t;
        
        x.height=Math.max((height(x.left),height(x.right))+1;
        y.height=Math.max((height(y.left),height(y.right))+1;
        return y;
    }
    class Node rotateLeft(Node x)
            {
        Node y=x.right;
        Node t=y.left;
        
        y.left=x;
        x.right=t;
        
        x.height=Math.max((height(x.left),height(x.right))+1;
        y.height=Math.max((height(y.left),height(y.right))+1;
        return y;
    }
    public Node insert(Node root,int data)
    {
        if(root==null)
        {
            return (new Node(data));
        }
        if(data<root.data)
        {
            root.left=insert(root.left,data);
        }
        else
            return root.right=insert(root.right,data);
        
        root.height=Math.max(height(root.left), height(root.right))+1;
        
        int balance=getbalance(root);
        
        if(balance>1 && data<root.left.data)
            return rotateRight(root);
        if(balance<-1 && data >root.right.data)
            return rotateLeft(root);
        if(balance>1 && data>root.left.data)
        {
            root.left=rotateLeft(root.left)
                    return rotateRight(root);
        }
        if(balance<-1 && data<root.right.data)
        {
            root.right=rotateRight(root.right)
                    return rotateLeft(root);
        }
        return root;
    }
    
    
     public void inorder(Node root)
    {
        if(root!=null)
        {
                                    

            inorder(root.left);
            System.out.println(root.da ta+"");
            inorder(root.right);

        }
//            System.out.println("Tree is Emptyy");
//            System.out.println("Null");/
    }
    public static void main(String[] args) {
        // TODO code application logic here
        AVLInsertion prac =new AVLInsertion(); 
                Node root=null;
        int []val={10,8,9,7,11,13};
        for(int i =0;i<val.length;i++)
        {
            root=prac.insert(root,val[i]);
        }
        
        prac.inorder(root);
    }
    
}
