/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package class_work;
/**
 *
 * @author ans shah55
 */
public class Class_work {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Date dob = new Date(8,7,2001);
        Date doj = new Date (21,11,2012);
        Employee person = new Employee("Ans","Shah",dob,doj);
        System.out.println(person);
        
    }
    
}
