/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package class_work;

/**
 *
 * @author ans shah55
 */
public class Employee {
    private String Fname;
    private String Lname;
    private Date dob;
    private Date doj;
     public Employee(String fn, String ln, Date db, Date dj)
    {
        this.setFname(fn);
        this.setLname(ln);
        this.setDob(db);
        this.setDoj(dj);
    }


    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Date getDoj() {
        return doj;
    }

    public void setDoj(Date doj) {
        this.doj = doj;
    }
    public String toString()
    {
         return String.format("First Name: %s\nLast Name: %s\nDate of Birth: %s\nDate of Joining: %s", this.getFname(),this.getLname(),this.getDob().toString(),this.getDoj().toString());
    }

    }
