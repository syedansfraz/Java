package binarytreefromlinkedlist;

public class BinaryTreeFromLinkedList {

   static Node root;

    class Node {

        int data;
        Node left, right;

        Node(int data1) {
            this.data = data1;
            this.left = null;
            this.right = null;
        }
    }

    public void insertRoot(int data) {
        Node newNode = new Node(data);
        if (root != null) {
            System.out.println("Root Already Exist");
            return;
        } else {
            root = newNode;
//            System.out.println(root.data);
        }
    }

    public void insertLeft(int parent, int data) {
        Node newNode = new Node(data);
        Node temp=search(parent,root);
        if(temp==null){
            System.out.println("Parent Not Found");
        }
        else {
            if(temp.left!=null)
            {
                System.out.println("Node Already exist");
            }
            else
                temp.left=newNode;
        }
//        Node temp=
    }
    
    public void insertRight(int parent, int data) {
        Node newNode = new Node(data);
        Node temp=search(parent,root);
        if(temp==null){
            System.out.println("Parent Not Found");
        }
        else {
            if(temp.right!=null)
            {
                System.out.println("Node Already exist");
            }
            else
                temp.right=newNode;
        }
//        Node temp=
    }

    public Node search(int parent, Node root) {
        if (root == null) {
            return null;
        } else {
            Node temp;
            if (root.data == parent) {
                return root;
            } else {
                temp = search(parent, root.left);
                if (temp == null) {
                    temp = search(parent, root.right);
                }

                return temp;
            }

        }
    }
    
    public void preorder(Node root)
    {
        if(root==null)
        {
//            System.out.println("Root not Exist");
            return;
        }
        else
        {
            System.out.println(""+root.data);
            preorder(root.left);
            preorder(root.right);
        }
    }
     public void inorder(Node root)
    {
        if(root==null)
        {
//            System.out.println("Root not Exist");
            return;
        }
        else
        {
            
            preorder(root.left);
            System.out.println(""+root.data);
            preorder(root.right);
        }
    }
    //    public void insert

    public static void main(String[] args) {
        BinaryTreeFromLinkedList tree = new BinaryTreeFromLinkedList();
        tree.insertRoot(12);
        tree.insertLeft(12, 7);
        tree.insertRight(12, 8);
//        tree.insertLeft(12, 7);
//        tree.preorder(root);
        tree.inorder(root);
        

    }

}
