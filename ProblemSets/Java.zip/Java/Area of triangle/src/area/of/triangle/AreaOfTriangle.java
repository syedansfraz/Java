/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package area.of.triangle;
import java.util.Scanner;
public class AreaOfTriangle {
    public static void main(String[] args) {
        double a,b,c,s,area,sqrt;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter value of a");
        a=input.nextDouble();
        System.out.println("Enter value of b");
        b=input.nextDouble();
        System.out.println("Enter value of c");
        c=input.nextDouble();
        s= (a+b+c) / 2;
        area = s * (s-a) * (s-b) * (s-c);
        sqrt = Math.sqrt(area);
        System.out.printf("Area = %.2f",sqrt);
        
        
        
        
        
        
    }
    
}
