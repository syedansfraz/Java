/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package copiedpostfixevaluation;

/**
 *
 * @author ans shah55
 */
public class Stack {
    public int max = 20;
    int top;
    double[] arr = new double[max];

    public boolean isEmpty() {
        if (top < 0) {
//            System.out.println("Stack Underflow");
            return true;
        } else {
            return false;
        }

    }

    public boolean isFull() {
        if (top == max - 1) {
//            System.out.println("Stack Overflow");
            return true;
        } else {
            return false;
        }
    }

    public void push(double a) {
        if (isFull()) {
            System.out.println("Stack Overflow");
//            return false;
        } else {
            top++;
//            System.out.println("Enter value:");
//            Scanner input=new Scanner(System.in);
//            int a= input.nextInt();
            arr[top] = a;
            System.out.println("Value Pushed");
//            return true;
        }

    }

    public double pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
//            return false;
return 0.0;
        }
        else
        {
            top--;
            System.out.println("Value popped");
            return arr[top];
//            return true;
        }
    }
    public void display()
    {
        for(int i=top;i>=0;i--)
        {
            System.out.println("\n"+arr[i]);
        }
    }


}
