/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package accountarray;

import java.util.Scanner;
public class AccountArray {
    public static void main(String[] args) {


    Account [] e=new Account[10];
    int i;
    Scanner input=new Scanner(System.in);
    for(int j=0;j<e.length;j++)
    {
        System.out.println("Enter 1 for Current Account\nEnter 2 for Saving Account");
        int a= input.nextInt();
        if(a==1)
        {
            System.out.println("Enter Account Number:");
            int accno=input.nextInt();
            System.out.println("Enter Account Balance:");
            double accbal=input.nextDouble();
            e[j]=new Current(accno,accbal);
        }
        else if(a==2)
        {
            System.out.println("Enter Account Number:");
            int accno1=input.nextInt();
            System.out.println("Enter Account Balance:");
            double accbal1=input.nextDouble();
            System.out.println("Enter Interest Rate:");
            double ir=input.nextDouble();
            e[j]=new Saving(ir,accno1,accbal1);
        }
        else
        {
            System.out.println("Wrong Choice!!");
        }
    }
    for(int j=0;j<e.length;j++)
    {
        e[j].display();
    }
}

    }
