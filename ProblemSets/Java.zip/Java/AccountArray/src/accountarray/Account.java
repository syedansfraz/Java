/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountarray;

/**
 *
 * @author ans shah55
 */
public abstract class Account {
       private int accno;
    private double accbal;

    public Account(int accno, double accbal) {
        this.accno = accno;
        this.accbal = accbal;
    }
    
    public int getAccno() {
        return accno;
    }

    public void setAccno(int accno) {
        this.accno = accno;
    }

    public double getAccbal() {
        return accbal;
    }

    public void setAccbal(double accbal) {
        this.accbal = accbal;
    }
    public abstract void display();
}
