/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountarray;

/**
 *
 * @author ans shah55
 */
public class Current extends Account{
       public Current(int accno, double accbal) {
        super(accno, accbal);
    }
    
    public void display()
    {
        System.out.println("Current Account Information");
        System.out.println("Account #:"+super.getAccno()+"\nAccount Balance:"+super.getAccbal());
    }
}
