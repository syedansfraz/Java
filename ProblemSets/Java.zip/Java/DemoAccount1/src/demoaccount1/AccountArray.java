package demoaccount1;import java.util.Scanner;
public class AccountArray {
    Account [] e=new Account[2];
    int i;
    Scanner input=new Scanner(System.in);
//    for(int i=0;i<e.length;i++)
    while(i<2)
    {
        System.out.println("Enter 1 for Current Account\nEnter 2 for Saving Account");
        int a= input.nextInt();
        if(a==1)
        {
            System.out.println("Enter Account Number:");
            int accno=input.nextInt();
            System.out.println("Enter Account Balance:");
            double accbal=input.nextDouble();
            e[i]=new Current(accno,accbal);
        }
        else
        {
            System.out.println("Enter Account Number:");
            int accno1=input.nextInt();
            System.out.println("Enter Account Balance:");
            double accbal1=input.nextDouble();
            System.out.println("Enter Interest Rate:");
            double ir=input.nextDouble();
            e[i]=new Saving(ir,accno1,accbal1);
        }
    }
    for(int j=0;j<e.length;j++)
    {
        e[j].display();
    }
}

