package demoaccount1;
import java.util.Scanner;
public class DemoAccount1 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter Account Number:");
        int a = input.nextInt();
        System.out.println("Enter Account Balance:");
        double b  = input.nextDouble();
        System.out.println("Enter Interest Rate:");
        double c=input.nextDouble();
        Current c1=new Current(a,b);
        Saving c2=new Saving(c,a,b);
        c1.display();
        c2.display();
        
    }
    
}
