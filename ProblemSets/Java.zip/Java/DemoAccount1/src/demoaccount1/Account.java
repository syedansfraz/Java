package demoaccount1;
public abstract class Account {
    private int accno;
    private double accbal;

    public Account(int accno, double accbal) {
        this.accno = accno;
        this.accbal = accbal;
    }
    
    public int getAccno() {
        return accno;
    }

    public void setAccno(int accno) {
        this.accno = accno;
    }

    public double getAccbal() {
        return accbal;
    }

    public void setAccbal(double accbal) {
        this.accbal = accbal;
    }
    public abstract void display();
    
}
