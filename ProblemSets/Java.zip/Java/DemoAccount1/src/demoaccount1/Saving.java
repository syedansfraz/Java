package demoaccount1;
public class Saving extends Account{
    private double intrate;

    public Saving(double intrate, int accno, double accbal) {
        super(accno, accbal);
        this.intrate = intrate;
    }

    public double getIntrate() {
        return intrate;
    }

    public void setIntrate(double intrate) {
        this.intrate = intrate;
    }
    public void display()
    {
        System.out.println("Saving Account Information");
        System.out.println("Account #:"+super.getAccno()+"\nAccount Balance:"+super.getAccbal()+"\nInterest Rate:"+this.intrate);
    }
    
    
}
