/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package enhanced;
import java.util.Scanner;
/**
 *
 * @author ans shah55
 */
public class Enhanced {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] a={1,2,3,4,5,6,7,8,9};
        for(int b:a)
        {
            System.out.println(""+b);
        }
        Scanner input=new Scanner(System.in);
        int f = input.nextInt();
        print(1,2,3,4,5,f);
    }
    public static void print(int... a)
    {
        for(int b:a)
        {
            System.out.println(""+b);
        }
    }
    
}
