package car.practice;
import java.util.Scanner;
public class CarTest {
    private double fuelEff;
    private double tankCap;
    private double fuelLev;
    Scanner input = new Scanner (System.in);
    public void setFE(double str)
    {
        this.fuelEff=str;
    }
    public double getFE()
    {
        return this.fuelEff;
    }
    public void setTC(double str)
    {
        this.tankCap=str;
    }
    public double getTC()
    {
        return this.tankCap;
    }
    public void setFL(double str)
    {
        this.fuelLev=str;
    }
    public double getFL()
    {
        return this.fuelLev;
    }
    public void setAF()
    {
        
        System.out.println("How much addition");
        double str=input.nextDouble();
        if (this.fuelLev+str>this.tankCap)
        {
            System.out.println("Unable to Add this much");
        }
        else
        {
            this.fuelLev= this.fuelLev+str;
        }
    }
    public void getTravel(double str)
    {
        double gc = str/this.fuelEff;
        if(this.fuelLev>=gc)
        {
            System.out.println("You Can Travel");
            this.fuelLev=this.fuelLev-gc;
        }
        else {
            
            System.out.println("You are out of Fuel\n If you want to add press 1...");
            
            int add=input.nextInt();
            if (add==1)
            {
                setAF();
            }
            else
            {
                System.out.println("Thank You");
            }
        }
    }
}
