package car.practice;
import java.util.Scanner;
public class CarPractice {
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        CarTest c = new CarTest();
        c.setFE(20.0);
        c.setFL(10.0);
        c.setTC(50.0);
        int press=1;
        System.out.println(" "+c.getFE()+" "+c.getFL()+" "+c.getTC());
        Scanner input = new Scanner(System.in);
        do{
            System.out.println("Which Function do you want to perform");
            System.out.println("1. Current Fuel\n2. Fuel Efficiency\n3. Tank Capacity\n4. Add Fuel\n5. Drive");
            int choice=input.nextInt();
        switch(choice)
        {
            
            case 1:
                System.out.println(""+c.getFL());
                break;
            case 2:
                System.out.println(""+c.getFE());
                break;
            case 3:
                System.out.println(""+c.getTC());
                break;
            case 4:
                c.setAF();
                break;
            case 5:
                System.out.println("Total Distance you want to travel");
                double tra=input.nextDouble();
                c.getTravel(tra);
                break;
            default:
            {
                System.out.println("Wrong Choice");
             
        }
        }
            System.out.println("Press 1 to Continue");
            press=input.nextInt();
        }while(press==1);
            
        
    }
    
}
