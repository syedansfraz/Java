/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package circularqueuepractice;

/**
 *
 * @author ans shah55
 */
public class CircularQueuePractice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        practice ans=new practice();
        ans.enqueue(12);
        ans.enqueue(13);
        ans.enqueue(11);
        System.out.println(ans.dequeue());
        System.out.println(ans.dequeue());
        System.out.println(ans.size());
                System.out.println(ans.dequeue());

        ans.enqueue(15);
        System.out.println(ans.dequeue());
        ans.enqueue(16);
        System.out.println(ans.dequeue());
        System.out.println(ans.size());
        

    }
    
}
