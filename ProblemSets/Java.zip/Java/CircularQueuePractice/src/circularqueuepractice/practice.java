/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package circularqueuepractice;

/**
 *
 * @author ans shah55
 */
public class practice {
    int tail=-1;
    int head=0;
    int size =3;
    int[] arr=new int[size];
    public boolean isFull()
    {
        if(tail==head+size-1)
        {
            return true;
        }
        else
            return false;
    }
    public boolean isEmpty()
    {
        if(tail<head)
        {
            return true;
        }
        else
            return false;
    }
    public void enqueue(int val)
    {
        if(!isFull())
        {
            tail++;
            arr[tail%size]=val;
        }
        else
            System.out.println("Queue is Full!");
    }
    public int dequeue()
    {
        if(!isEmpty())
        {
            int val=arr[tail%size];
            head++;
            return val;
        }
        else
            System.out.println("Queue is Empty!");
        return  -9999;
    }
    public int size()
    {
        return tail-head+1;
    }
}
