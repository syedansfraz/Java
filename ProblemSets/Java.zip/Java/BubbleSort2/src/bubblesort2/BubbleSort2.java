/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bubblesort2;

/**
 *
 * @author ans shah55
 */
public class BubbleSort2 {
    public static void bubble(int [] arr)
    {
        for(int i =0;i<=arr.length;i++)
        {
            for(int j=1;j<arr.length;j++)
            {
                if(arr[j-1]>arr[j])
                {
                    int temp=arr[j-1];
                    arr[j-1]=arr[j];
                    arr[j]=temp;
                }
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arr={4,8,3,99,1};
        bubble(arr);
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(""+arr[i]);
        }
        
    }
    
}
