package avltreepractice;
import java.io.*;
import java.util.*;
public class AVLTreePractice {

    class Node {

        int data;
        Node left;
        Node right;
        private int height;

        Node(int data1) {
            this.data = data1;
        }
    }
    
    public int height(Node root){
        if(root==null)
            return 0;
        return root.height;
    }
    
    public int getbalance(Node root)
    {
        if(root!=null)
            return height(root.left)-height(root.right);
        return 0;
    }
    
    public Node rightRotate(Node y)
    {
        Node x=y.left;
        Node t1=x.right;
        
        x.right=y;
        y.left=t1;
        
        y.height = Math.max(height(y.left), height(y.right))+1;
        x.height = Math.max(height(x.left), height(x.right))+1;
        
        return x;
    }
    
    public Node leftRotate(Node x)
    {
        Node y=x.right;
        Node t2=y.left;
        
        y.left=x;
        x.right=t2;
        
        x.height = Math.max(height(x.left), height(x.right))+1;
        y.height = Math.max(height(y.left), height(y.right))+1;

        // Return new root
        return y;
    }

    public Node insert(Node root, int data) {
        if (root == null) {
            return (new Node(data));}
        if (data < root.data) {
            root.left = insert(root.left, data);
        } else {
            root.right = insert(root.right, data);
        }
        root.height=Math.max(height(root.left), height(root.left))+1;
        int balance = getbalance(root);
//        System.out.println(root.data);
        if(balance >1 && data<root.left.data){
            return rightRotate(root);
        }
        
        if(balance <-1 && data>root.right.data)
        {
            return leftRotate(root);
        }
        if (balance>1 && data>root.left.data)
        {
            root.left =  leftRotate(root.left);
            return rightRotate(root);
        }
        if(balance <-1 && data<root.right.data){
            root.right=rightRotate(root.right);
            return leftRotate(root);
        }
        return root;
    }
    
    public void inorder(Node root)
    {
        if(root!=null)
        {
                                    System.out.println(root.data+"");

            inorder(root.left);
            inorder(root.right);

        }
//            System.out.println("Tree is Emptyy");
//            System.out.println("Null");/
    }

    public static void main(String[] args) {
        // TODO code application logic here
        
        AVLTreePractice prac = new AVLTreePractice();
        Node root=null;
        int []val={10,8,9,7,11,13};
        for(int i =0;i<val.length;i++)
        {
            root=prac.insert(root,val[i]);
        }
//        prac.insert(root, 10);
//        prac.insert(root, 8);
//        prac.insert(root, 9);
//        prac.insert(root, 7);
//        prac.insert(root, 11);
//        prac.insert(root, 13);
//        prac.insert(root, 21);
        prac.inorder(root);
    }

}
