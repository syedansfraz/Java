package a3p3;
public class A3P3 {
    public static void main(String[] args) {
        // TODO code application logic here
        int[] pt = new int[5];
        int[] st = new int[4];
        int[][] sales = {{51, 22, 41, 21},
        {20, 42, 12, 52},
        {10, 32, 34, 52},
        {90, 23, 12, 45},
        {29, 14, 52, 12}};
        System.out.printf("%10s%10s%10s%10s%10s%10s\n", "Products", "Per 1", "Per 2", "Per3", "Per4", "Total");
        for (int i = 0; i < pt.length; i++) {
            System.out.printf("%10d", i + 1);
            for (int j = 0; j < st.length; j++) {
                System.out.printf("%10d", sales[i][j]);
                pt[i] += sales[i][j];
                st[j] += sales[i][j];
            }
            System.out.printf("%10d\n", pt[i]);
        }
        System.out.printf("%10s%10d%10d%10d%10d", "TOTAL:", st[0], st[1], st[2], st[3]);
    }
}
