package classa;
public class ClassB extends ClassA{
    public ClassB()
    {
        System.out.println("No Argument of B");
    }
        public ClassB(int x)
    {
        System.out.println("No Argument of B");
    }
    
}
