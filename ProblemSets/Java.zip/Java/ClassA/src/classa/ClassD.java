/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classa;

/**
 *
 * @author ans shah55
 */
public class ClassD extends ClassC {
    
    public ClassD()
    {
        System.out.println("No Argument of D");
    }
            public ClassD(int x)
    {
        System.out.println("No Argument of B");
    }
    
    
}
