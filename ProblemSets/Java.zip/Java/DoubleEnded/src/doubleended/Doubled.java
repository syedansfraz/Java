/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package doubleended;

/**
 *
 * @author ans shah55
 */
public class Doubled {
    int head=0;
    int tail=-1;
    int size=5;
    int [] arr=new int[size];
    public boolean isFull(){
        if(tail==size-1)
            return true;
        return false;
    }
    public boolean isEmpty(){
        if(tail<0)
            return true;
        return false;
    }
    public void EnqueueAtTail(int val)
    {
        if(!isFull()){
            tail++;
            arr[tail]=val;
        }
        else
            System.out.println("Queue is Full");
    }
    public int DequeueAtTail()
    {
        if(!isEmpty())
        {
            int val=arr[tail];
            tail--;
            return val;
        }
        else
        {
            System.out.println("Queue is Empty");
            return -999;
        }
    }
    public void EnqueueAtHead(int val)
    {
        if(!isFull())
        {
//            int val;
            moveback();
            arr[head]=val;
        }
    }
    public void moveback()
    {
        for(int i=tail;i>=0;i--)
        {
            arr[i+1]=arr[i];
        }
    }
    public int DequeueAtHead(){
        if(!isEmpty())
        {
            int val=arr[head];
            movefwd();
            return val;
        }
        else
        {
            System.out.println("Queue is Empty");
            return -999;
        }
    }
    public void movefwd()
    {
        for(int i=0;i<tail;i++)
        {
            arr[i]=arr[i+1];
        }
    }
    public void Queue()
    {
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(""+arr[i]);
        }
    }
}
