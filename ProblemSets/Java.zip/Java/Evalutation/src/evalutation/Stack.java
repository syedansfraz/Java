/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package evalutation;

/**
 *
 * @author ans shah55
 */
public class Stack {
    int size=30;
        int[] arr=new int[size];
        int top=-1;
        public boolean isFull(){
            if(top==size-1)
            
                return true;
            return false;
            
        }
        public boolean isEmpty(){
            if(top<0)
                return true;
            return false;
        }
        public void push(int val)
        {
            if(!isFull())
            {
                top++;
                arr[top]=val;
            }
            else
            {
                System.out.println("Stack Overflow");
            }
        }
        public int pop()
        {
            if(!isEmpty())
            {
                int val=arr[top];
                top--;
                return 0;
            }
            else
            {
                System.out.println("Stack Underflow");
                return 0;
            }
        }
        public int front(){
            if(!isEmpty())
            return arr[top];
            return 0;
        }
        public int size()
        {
            return top+1;
        }
}
