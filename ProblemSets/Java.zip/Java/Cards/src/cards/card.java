/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cards;

/**
 *
 * @author ans shah55
 */
public class card {
    private String fc;
    private String st;
    public card(String fc,String st)
    {
        this.setFc(fc);
        this.setSt(st);
    }
    public String toString()
    {
        return String.format("%s of %s", this.getFc(),this.getSt());
    }
    public String getFc() {
        return fc;
    }

    public void setFc(String fc) {
        this.fc = fc;
    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }
    
}
