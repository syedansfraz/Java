package demoaccount;
import java.util.Scanner;
public class DemoAccount {
    public static void main(String[] args) {
        Scanner inp=new Scanner(System.in);
        System.out.println("Account number:");
        int a=inp.nextInt();
        System.out.println("Account Balance:");
        double b=inp.nextDouble();
        Current c=new Current (a,b);
        c.display1();
        System.out.println("Interest Rate:");
        double intr=inp.nextDouble();
        Saving d = new Saving (a,b,intr);
        d.Display2();
    }
}
