package demoaccount;
public class Saving extends Account
{
   private double interest;
   private int an;
    private double ab;

    public Saving(int an, double ab,double c)
    {
        super(an,ab);
        this.setAb(ab);
        this.setAn(an);
        this.setInterest(c);
    }

    public int getAn() {
        return an;
    }

    public void setAn(int an) {
        this.an = an;
    }

    public double getAb() {
        return ab;
    }

    public void setAb(double ab) {
        this.ab = ab;
    }
    
    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }
    public void Display2()
    {
        super.Display();
        System.out.println("Account Number:"+this.an+"\nAccount Balance:"+this.ab+"\nInterest Rate:"+this.interest);   
    }
}
