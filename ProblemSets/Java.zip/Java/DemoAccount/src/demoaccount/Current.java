package demoaccount;
public class Current extends Account
{
    private int an;
    private double ab;

    public Current(int an, double ab)
    {
        super(an,ab);
        this.setAb(ab);
        this.setAn(an);
    }
    
    public int getAn() {
        return an;
    }
    public void setAn(int an) {
        this.an = an;
    }
    public double getAb() {
        return ab;
    }
    public void setAb(double ab) {
        this.ab = ab;
    }
    public void display1()
    {
         super.Display();
         System.out.println("Account Number:"+this.an+"\nAccount Balance:"+this.ab);
         
    }
   
}
