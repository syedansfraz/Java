package demoaccount;
public class Account extends Object
{
    private int accountno;
    private double accountbal;
        public Account(int accountno, double accountbal) {
        this.accountno = accountno;
        this.accountbal = accountbal;
    }
    public double getAccountno() {
        return accountno;
    }

    public void setAccountno(int accountno) {
        this.accountno = accountno;
    }

    public double getAccountbal() {
        return accountbal;
    }

    public void setAccountbal(double accountbal) {
        this.accountbal = accountbal;
    }
    public void Display()
    {
         System.out.println("Account information");
    }
//     @Override
//    public String toString()
//    {
//           return String.format("\nAccount Number:%d \nAccount balance:%f",this.accountno,this.accountbal);
//    }
//    public String toString()
//    {
//           return String.format();
//    }
    
}
