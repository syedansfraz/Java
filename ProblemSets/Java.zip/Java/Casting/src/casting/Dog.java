/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casting;

/**
 *
 * @author ans shah55
 */
public class Dog extends Animal
{
    public void sound()
    {
        System.out.println("Grrrrrr");
    }
    public void sound(String a)
    {
        System.out.println("My name is "+a);
    }
}
