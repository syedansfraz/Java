package casting;
public class Casting {
    public static void main(String[] args) {
        Animal a= new Animal();
        a.sound();
        Animal b= new Dog();
        b.sound();
        Animal c = new Cat();
        c.Gender();
        c.sound();//OverRidding
        Animal f=new Dog ();
        Dog d=(Dog)f;
        d.sound("Mickyyyy");//Overloading
    }
    
}
