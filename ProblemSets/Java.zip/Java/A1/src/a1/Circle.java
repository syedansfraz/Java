/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a1;

public class Circle {
private double radius;
 public void setRadius(double r){
 this.radius = r;
 }
 public double getRadius(){
return radius;
 }
 public double getArea(){
return 3.14*radius*radius;
 }
 public double getCircumference(){
return 2*3.14*radius;
 }
}
