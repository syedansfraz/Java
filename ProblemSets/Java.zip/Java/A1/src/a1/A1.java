/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package a1;
import java.util.Scanner;
public class A1 { 
    public static void main(String[] args) {
    Scanner inp = new
Scanner(System.in); Circle obCircle =
new Circle();
 Circle obCircle2 = new Circle();
 System.out.println("Enter the value of radius.\n");
obCircle.setRadius(inp.nextDouble());
 System.out.println("\nArea:" + obCircle.getArea());
 System.out.println("_________________________________________________");
 System.out.println("Circumference:" + obCircle.getCircumference());
 System.out.println("_________________________________________________");
System.out.println("Enter the value of radius.\n"); obCircle2.setRadius(inp.nextDouble());
 System.out.println("\nArea:" + obCircle2.getArea());
 System.out.println("_________________________________________________");
System.out.println("\nCircumference:" + obCircle2.getCircumference());
 inp.close();
 }
}