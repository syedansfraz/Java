package a2q2;
public class A2Q2 {
    public static void main(String[] args) {
        
    }
    
}
